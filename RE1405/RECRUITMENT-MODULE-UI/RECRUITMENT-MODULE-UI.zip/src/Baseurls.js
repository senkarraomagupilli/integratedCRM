export const baseurl = "http://172.206.114.140:8080/RecruitmentApplication/api/v1.0/";
export const imgUrl = "http://172.206.114.140:8080/";